<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Value;
use Faker\Generator as Faker;

$factory->define(Value::class, function (Faker $faker) {
    return [
        //
    ];
});
